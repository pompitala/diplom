//package com.example.springsecurityapplication.security;
//
//import com.example.springsecurityapplication.services.PersonDetailsService;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.AuthenticationException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.stereotype.Component;
//
//import java.util.Collections;
//
//
////в этом классе мы будем прописывать всю логику по идентификации пользователя, данный класс должен иметь аннотацию @Component и он должен наследовать интерфейс AuthenticationProvider и реализовывать все методы данного интерфейса (нажать Implemets methods)
//@Component
//public class AuthenticationProvider implements org.springframework.security.authentication.AuthenticationProvider {
//    //поле хранит объект PersonDetails, внедряем его с помощью конструктора
//    private final PersonDetailsService personDetailsService;
//    //конструктор
//    public AuthenticationProvider(PersonDetailsService personDetails) {
//        this.personDetailsService = personDetails;
//    }
//
//
//
//    //наследуемый метод, прописываем его настройку
//    // логин и пароль будет помещаться в объект аутентификации, как только нажимается кнопка Войти, в этот объект с формы помещаются данные, с помощью .getName(); мы извлекаем логин, далее данный логин нужно сравнить с логином в БД
//    @Override
//    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
//        //получаем логин с формы аутентификации. За нас Spring Security сам создаст объект формы и передаст его в объект аутентификации.
//        String login = authentication.getName();
//
//        //обращаемся к personDetailsService и от туда вызываем метод .loadUserByUsername и передаём туда login, кладём это всё в объект UserDetails
//        //т.к. данный метод возвращает объект интерфейса UserDetails, то и объект мы создадим через интерфейс
//        UserDetails person = personDetailsService.loadUserByUsername(login);
//
//        //получаем пароль с формы
//        String password = authentication.getCredentials().toString();
//        //сравниваем, метод .equals позволяет нам сравнить два объекта, либо две строки, здесь сравниваем пароль который получили из объекта аутентификации с паролем из его объекта
//        if (!password.equals(person.getPassword())){
//            throw  new BadCredentialsException("Не корректный пароль");
//        }
//        //возвращаем объект аутентификации, в данном объекте будет лежать объект самого пользователя, его пароль и список его ролей
//        return new UsernamePasswordAuthenticationToken(person, password, Collections.emptyList());
//    }
//
//    //наследуемый метод, указывает для каких случаев можно применять данный класс, true-значит в нашем приложении при всех случаях, при проверке данных всегда будет использоваться AuthenticationProvider
//    @Override
//    public boolean supports(Class<?> authentication) {
//        return true;
//    }
//}

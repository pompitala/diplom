package com.example.springsecurityapplication.controllers;

import com.example.springsecurityapplication.repositories.ProductRepository;
import com.example.springsecurityapplication.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

//здесь логика по работе с товарами пользователей, которые  не вошли в личный кабинет
@Controller
@RequestMapping("/product")//начало пути для остальных методов, чтобы все время не писать в начале /product
public class ProductController {
    //внедрим ProductService, ProductRepository через конструктор
    private final ProductService productService;
    private final ProductRepository productRepository;
    //конструктор
    public ProductController(ProductService productService, ProductRepository productRepository) {
        this.productService = productService;
        this.productRepository = productRepository;
    }

    //Выводятся все товары для не зарегистрированных пользователей
    //Позволяет получить список всех продуктов
    //будет срабатывать на /product, мы это не указываем, потому это начало пути указано вверху
    @GetMapping("")
    public String getAllProduct(Model model){
        //в модель положим новый аттрибут, чтобы к этому аттрибуту можно было обратиться на нашем шаблоне, в качестве ключа будет products, в качестве значения у нас будет то что нам вернет метод getAllProduct() нашего репозитория (он возвращает лист продуктов, т.е. мы лист продуктов кладём в модель)
        model.addAttribute("products", productService.getAllProduct());

        //возвращаем (у нас есть папка Продукт и в ней шаблон Продукт)
        return "/product/product";
    }

    //При нажатии на ссылку продукта (для перехода в карточку продукта)
    //получаем id товара на который нажали, создаём модель
    //в модель положили аттрибут по ключу "product", обратидись к productService и его метод вернул нам продукт по конкретному id
    @GetMapping("/info/{id}")
     public String infoProduct(@PathVariable("id") int id, Model model){
        model.addAttribute("product", productService.getProductId(id));
        return "/product/infoProduct";
    }

    // работа с формой фильтрации
    //принимаем поля с формы
    //required = false) - означает, что данный радиобаттон может быть как выбран, так и не выбран и defaultValue = " " - дефолтное значение, если параметр не придёт
    //и создаём принимаем модель
    @PostMapping("/search")
    public String productSearch(@RequestParam("search") String search, @RequestParam("ot") String ot, @RequestParam("do") String Do, @RequestParam(value = "price", required = false, defaultValue = "") String price, @RequestParam(value = "contract", required = false, defaultValue = "") String contract, Model model) {
        //чтобы при перезагрузке страницы поля поиска не очищались
        //мы параметры обратно кладём в модель, возвращаем эту страницу и на этой странице мы должны внедрить значения в эти поля с помощью th:value="*{}
        model.addAttribute("products", productService.getAllProduct());

        if(!ot.isEmpty() & !Do.isEmpty()){
            if(!price.isEmpty()){
                if(price.equals("sorted_by_ascending_price")) {
                    if (!contract.isEmpty()) {
                        if (contract.equals("furniture")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
                        } else if (contract.equals("appliances")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
                        } else if (contract.equals("clothes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
                        }
                    } else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
                    }
                } else if(price.equals("sorted_by_descending_price")){
                    if(!contract.isEmpty()){
                        if(contract.equals("furniture")){
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
                        }else if (contract.equals("appliances")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
                        } else if (contract.equals("clothes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
                        }
                    }  else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
                    }
                }
            } else {
                model.addAttribute("search_product", productRepository.findByTitleAndPriceGreaterThanEqualAndPriceLessThanEqual(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
            }
        } else {
            model.addAttribute("search_product", productRepository.findByTitleContainingIgnoreCase(search));
        }

        model.addAttribute("value_search", search);
        model.addAttribute("value_price_ot", ot);
        model.addAttribute("value_price_do", Do);
        return "/product/product";

    }
}

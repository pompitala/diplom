package com.example.springsecurityapplication.configs;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class Config implements WebMvcConfigurer {
    @Value("${upload.path}")
    private String uploadPath;

    //переопределяем метод
    //если где-то на контроллере мы обращаемся к /img необходимо открыть путь ("file:///" + uploadPath + "/") file:/// - это папка нашего компьютера
    //т.е вместо img будет подставляться путь до папки с фото
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/img/**")
                .addResourceLocations("file:///" + uploadPath + "/");
    }
}

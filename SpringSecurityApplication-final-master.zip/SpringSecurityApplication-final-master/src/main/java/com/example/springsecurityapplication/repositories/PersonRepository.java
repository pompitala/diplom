package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {
    //метод позволит найти запись в сущности Person по логину
    //здесь используется Optional<Person> потому что здесь может быть как найден, так и не найден человек
    Optional<Person> findByLogin(String login);



    @Query(value = "select * from person where role LIKE %?1", nativeQuery = true)
    List<Person> findByRole(String role);
}
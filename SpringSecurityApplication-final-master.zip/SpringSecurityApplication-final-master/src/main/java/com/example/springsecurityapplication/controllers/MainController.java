package com.example.springsecurityapplication.controllers;

import com.example.springsecurityapplication.enumm.Status;
import com.example.springsecurityapplication.models.Cart;
import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import com.example.springsecurityapplication.models.Product;
import com.example.springsecurityapplication.repositories.CartRepository;
import com.example.springsecurityapplication.repositories.OrderRepository;
import com.example.springsecurityapplication.repositories.ProductRepository;
import com.example.springsecurityapplication.security.PersonDetails;
import com.example.springsecurityapplication.services.PersonService;
import com.example.springsecurityapplication.services.ProductService;
import com.example.springsecurityapplication.util.PersonValidator;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
public class MainController {
    //внедряем валидатор и personService, productService, productRepository,cartRepository, orderRepository через конструктор
    private final PersonValidator personValidator;
    private final PersonService personService;
    private final ProductService productService;
    private final ProductRepository productRepository;
    private  final CartRepository cartRepository;
    private final OrderRepository orderRepository;

    public MainController(PersonValidator personValidator, PersonService personService, ProductService productService, ProductRepository productRepository, CartRepository cartRepository, OrderRepository orderRepository) {
        this.personValidator = personValidator;
        this.personService = personService;
        this.productService = productService;
        this.productRepository = productRepository;
        this.cartRepository = cartRepository;
        this.orderRepository = orderRepository;
    }

    //срабатывает при идентификации (при вводе логина и пароля)
    @GetMapping("/personAccount")
    public String index(Model model){
        //получим объект аутентифицированного пользователя с помощью SpringContextHolder из сессии, обращаемся к контексту и на нем вызываем метод аутентификации. Из сессии текущего пользователя получаем объект, который был положен в данную сессию после аутентификации пользователя
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //преобразовываем объект аутентификации в PersonDetails, чтобы можно было с помощью этого класса работать с данными пользователя
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();

        //получим роль пользователя в переменную role
        //по personDetails мы извлекаем Person и из Person извлекаем Role
        String role = personDetails.getPerson().getRole();

        //если роль пользователя Админ, то он переходит на страницу администратора, если нет, то он вернется на страницу index
        if(role.equals("ROLE_ADMIN")){
            return "redirect:/admin";
        }

        //получаем данные о пользователе в консоль
//        System.out.println(personDetails.getPerson());
//        System.out.println("ID пользователя: " + personDetails.getPerson().getId());
//        System.out.println("Логин пользователя: " + personDetails.getPerson().getLogin());
//        System.out.println("Пароль пользователя: " + personDetails.getPerson().getPassword());
//        System.out.println(personDetails);
    //
        //отправляем пользователя на главную страницу (если не соответствует никаким if)
        model.addAttribute("products", productService.getAllProduct());
        return "user/index";
    }

    //функционал для регистрации
    //1 способ работы с моделью
    //метод позволит открыть форму для регистрации новых пользователей,в параметры добавим объект модели. И к модели добавим один атрибут. Атрибут будет называться person и в качестве значения атрибута создадим новый объект модели Person. Возвращаем шаблон регистрации
//    @GetMapping("/registration")
//    public String registration (Model model){
//        model.addAttribute("person", new Person());
//        return "registration";
//    }

    //2 способ работы с моделью
    //тоже самое, что и первый способ, только другая запись. Используя аннотацию @ModelAttribute, при отправке формы Spring сам положит объект в модель
    @GetMapping("/registration")
    public String registration (@ModelAttribute("person") Person person){
        return "registration";
    }

    // метод позволит обработать данные с нашей формы registration
    //в параметрах принимаем объект с формы, указываем, что наша модель должна валидироваться и все ошибки валидации мы положим в BindingResult
    //обращаемся к personValidator вызываем метод validate, который позволит нам проверить данные, передаём в него объект person и объект ошибки
    // если ошибки есть, мы возвращаем форму регистрации на которой все ошибки отобразяться
    // если ошибки нет, то мы обращаемся к personService и вызываем метод регистрации в который мы передаём объект
    @PostMapping("/registration")
    public String resultRegistration(@ModelAttribute("person") @Valid Person person, BindingResult bindingResult){
        personValidator.validate(person, bindingResult);
        if(bindingResult.hasErrors()){
            return "registration";
        }
        personService.register(person);
        return "redirect:/personAccount";
    }

    //Срабатывает при переходе на страницу аутентифицированного пользователя
    // Чтобы в аккаунте пользователя выводились все товары
    @GetMapping("/personAccount/product")
    public String getAllProduct(Model model){
        //в модель положим новый аттрибут, чтобы к этому аттрибуту можно было обратиться на нашем шаблоне, в качестве ключа будет products, в качестве значения у нас будет то что нам вернет метод getAllProduct() нашего репозитория (он возвращает лист продуктов, т.е. мы лист продуктов кладём в модель)
        model.addAttribute("products", productService.getAllProduct());

        //возвращаем (у нас есть папка Продукт и в ней шаблон Продукт)
        return "/user/index";
    }

    //При нажатии на ссылку продукта  в кабинете пользователя (для перехода в карточку продукта)
    //получаем id товара на который нажали, создаём модель
    //в модель положили аттрибут по ключу "product", обратидись к productService и его метод вернул нам продукт по конкретному id
    @GetMapping("/personAccount/product/info/{id}")
    public String infoProduct(@PathVariable("id") int id, Model model){
        model.addAttribute("product", productService.getProductId(id));
        return "/product/infoProduct";
    }

    //поиск товара
    @PostMapping("/personAccount/search")
    public String productSearch(@RequestParam("search") String search, @RequestParam("ot") String ot, @RequestParam("do") String Do, @RequestParam(value = "price", required = false, defaultValue = "") String price, @RequestParam(value = "contract", required = false, defaultValue = "") String contract, Model model) {
        //чтобы при перезагрузке страницы поля поиска не очищались
        //мы параметры обратно кладём в модель, возвращаем эту страницу и на этой странице мы должны внедрить значения в эти поля с помощью th:value="*{}
        model.addAttribute("products", productService.getAllProduct());

        if(!ot.isEmpty() & !Do.isEmpty()){
            if(!price.isEmpty()){
                if(price.equals("sorted_by_ascending_price")) {
                    if (!contract.isEmpty()) {
                        if (contract.equals("furniture")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
                        } else if (contract.equals("appliances")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
                        } else if (contract.equals("clothes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
                        }
                    } else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
                    }
                } else if(price.equals("sorted_by_descending_price")){
                    if(!contract.isEmpty()){
                        if(contract.equals("furniture")){
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
                        }else if (contract.equals("appliances")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
                        } else if (contract.equals("clothes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
                        }
                    }  else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
                    }
                }
            } else {
                model.addAttribute("search_product", productRepository.findByTitleAndPriceGreaterThanEqualAndPriceLessThanEqual(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
            }
        } else {
            model.addAttribute("search_product", productRepository.findByTitleContainingIgnoreCase(search));
        }

        model.addAttribute("value_search", search);
        model.addAttribute("value_price_ot", ot);
        model.addAttribute("value_price_do", Do);
        return "/user/index";
    }

    //При нажатии на кнопку Добавление товара в корзину
    //принимаем id из ссылки
    @GetMapping("/cart/add/{id}")
    public String addProductInCart(@PathVariable("id") int id, Model model){
        //по id ищем объект продукта который пользователь хочет добавить
        Product product = productService.getProductId(id);

        //извлекаем объект аутентифицированного пользователя из сессии
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //приводим authentication к типу PersonDetails, чтобы узнать подробную информацию о пользователе
        //т.е. из модели объекта аутентификации взяли модель Person
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();

        //извлекаем id пользователя из объекта
        int id_person = personDetails.getPerson().getId();

        //формируем новую корзину и сохраняем в БД
        Cart cart = new Cart(id_person, product.getId());
        cartRepository.save(cart);
        return "redirect:/cart";
    }

    //обработаем "redirect:/cart" (заход в корзину)
    //как только пользователь заходит на страницу корзины, мы должны взять объект аутентификации, преобразовать в personDetails и получить id того пользователя который заходит в корзину
    @GetMapping("/cart")
    public String cart(Model model){
        //извлекаем объект аутентифицированного пользователя из сессии
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //приводим authentication к типу PersonDetails, чтобы узнать подробную информацию о пользователе
        //т.е. из модели объекта аутентификации взяли модель Person
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();
        //извлекаем id пользователя из объекта
        int id_person = personDetails.getPerson().getId();

        //возвращаем записи из корзины по id пользователя
        List<Cart> cartList = cartRepository.findByPersonId(id_person);
        //получаем из этой корзины список всех товаров, чтобы отобразить их в корзине
        List<Product> productList = new ArrayList<>();
        for (Cart cart : cartList
             ) {
            productList.add(productService.getProductId(cart.getProductId()));
        }

        //вычисление итоговой цены в корзине
        float price = 0;
        for (Product product : productList) {
            price+=product.getPrice();
        }
        model.addAttribute("price", price);

        //добавляем лист продуктов в модель
        model.addAttribute("cart_product", productList);

        return "/user/cart";
    }

    //Удаление товара из корзины
    @GetMapping("/cart/delete/{id}")
    public String deleteProductFromCart(Model model, @PathVariable("id") int id){
        //извлекаем объект аутентифицированного пользователя из сессии
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //приводим authentication к типу PersonDetails, чтобы узнать подробную информацию о пользователе
        //т.е. из модели объекта аутентификации взяли модель Person
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();
        //извлекаем id пользователя из объекта
        int id_person = personDetails.getPerson().getId();

        //возвращаем записи из корзины по id пользователя
        List<Cart> cartList = cartRepository.findByPersonId(id_person);
        //получаем из этой корзины список всех товаров, чтобы отобразить их в корзине
        List<Product> productList = new ArrayList<>();
        for (Cart cart : cartList
        ) {
            productList.add(productService.getProductId(cart.getProductId()));
        }
        cartRepository.deleteByCartProductId(id);

        return "redirect:/cart";
    }

    //работа с заказом
    @GetMapping("/order/create")
    public String order(){
        //извлекаем объект аутентифицированного пользователя из сессии
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //приводим authentication к типу PersonDetails, чтобы узнать подробную информацию о пользователе
        //т.е. из модели объекта аутентификации взяли модель Person
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();
        //извлекаем id пользователя из объекта
        int id_person = personDetails.getPerson().getId();

        //возвращаем записи из корзины по id пользователя
        List<Cart> cartList = cartRepository.findByPersonId(id_person);
        //получаем из этой корзины список всех товаров, чтобы отобразить их в корзине
        List<Product> productList = new ArrayList<>();
        for (Cart cart : cartList
        ) {
            productList.add(productService.getProductId(cart.getProductId()));
        }

        //вычисление итоговой цены
        float price = 0;
        for (Product product : productList) {
            price+=product.getPrice();
        }

        //сгенерируем уникальный номер заказа
        String uuid = UUID.randomUUID().toString();
        //перебираем товары через цикл, и для каждого из товаров генерируем запись в сущности Order
        //под каждый продукт создаётся объект заказа и этот объект мы сохраняем в БД
        for (Product product : productList){
            Order newOrder = new Order(uuid, product,personDetails.getPerson(), 1,product.getPrice(), Status.Оформлен);
           orderRepository.save(newOrder);
            //очищаем корзину
            cartRepository.deleteByCartProductId(product.getId());
        }
        return "redirect:/orders";
    }

    //При нажатии на кнопку Заказы
    @GetMapping("/orders")
    public String orderUser(Model model){
        //извлекаем объект аутентифицированного пользователя из сессии
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        //приводим authentication к типу PersonDetails, чтобы узнать подробную информацию о пользователе
        //т.е. из модели объекта аутентификации взяли модель Person
        PersonDetails personDetails = (PersonDetails) authentication.getPrincipal();
        //получим список всех заказов пользователя
        List<Order> orderList = orderRepository.findByPerson(personDetails.getPerson());
        //этот список кладём в модель, чтобы потом к нему обратиться
        model.addAttribute("orders", orderList);
        return "/user/orders";
    }
}

package com.example.springsecurityapplication.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;
import java.util.Objects;

@Entity //данный класс является моделью
@Table(name = "Person")// подключаемся к существующей в БД таблице с нименованием Person
public class Person {
    @Id //первичный ключ
    @Column(name = "id")// с каким полем мы хотим связать ключ, если поля еще нет, то это наименование возьмется в качестве поля, если поле есть, то мы к нему конектимся
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;


    //валидация поля
    @NotEmpty(message = "Логин не может быть пустым") // на пустоту
    @Size(min = 5, max = 100, message = "Логин должен быть от 5 до 100 символов")// на размер
    @Column(name = "login") // связываем поле модели с колонкой таблицы
    private String login;

    //валидация поля
    @NotEmpty(message = "Пароль не может быть пустым") // на пустоту
    @Column(name = "password") // связываем поле модели с колонкой таблицы
    private String password;

    @Column(name="role")
    private String role;

    //поле для связи с корзиной (многие ко многим)
    //для этой связи создаётся третья промежуточная таблица name = "product_cart" и в ней колонки (первое поле относится к текущей модели с которой мы работаем)
    //такая же связь должна быть прописана в product модели
    @ManyToMany()
    @JoinTable(name = "product_cart", joinColumns = @JoinColumn(name = "person_id"), inverseJoinColumns = @JoinColumn(name = "product_id"))
    private List<Product> productList;

    //поле для связи с заказом
    @OneToMany(mappedBy = "person", fetch = FetchType.EAGER)
    private List<Order> orderList;



    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return id == person.id && Objects.equals(login, person.login) && Objects.equals(password, person.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, login, password);
    }
}

package com.example.springsecurityapplication.security;

import com.example.springsecurityapplication.models.Person;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

//Обычно такие классы всегда именуют так: кемелкейс + первое слово это наименование модели с которой будем работать далее слово Details
//данный класс по умолчанию должен имплементировать интерфейс UserDetails и так же реализовывать ряд его методов (нажать Implements method), с помощью данного интерфейса, мы будем получать подробную информацию о конкретном пользователе который сейчас хочет авторизоваться
public class PersonDetails implements UserDetails {
    //поле которое будет хранить объект модели Person
    private final Person person;
    // внедряем это поле при помощи конструктора
    public PersonDetails(Person person) {
        this.person = person;
    }

    //метод будет возвращать объект пользователя после успешной аутентификации (далее мы по нему будем извлекать объект пользователя)
    public Person getPerson(){
        return this.person;
    }

    //метод возвращает роль текущего пользователя
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList((new SimpleGrantedAuthority(person.getRole())));
    }

    //метод отвечает за возвращение пароля конкретного пользователя
    @Override
    public String getPassword() {
        return this.person.getPassword();
    }

    @Override
    public String getUsername() {
        return this.person.getLogin();
    }

    //Аккаунт действителен
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    //Аккаунт не заблокирован
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    //Пароль является действительным
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    //Действительность аккаунта (активен или деактивирован)
    @Override
    public boolean isEnabled() {
        return true;
    }
}

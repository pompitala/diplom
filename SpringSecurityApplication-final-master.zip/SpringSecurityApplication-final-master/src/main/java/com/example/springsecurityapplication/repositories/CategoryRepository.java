package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


// наследуем  JpaRepository и указываем, что мы будем работать с моделью Category и с типом данных Integer
@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

    //метод возвращает категорию по её наименованию
    com.example.springsecurityapplication.models.Category findByName (String name);
}

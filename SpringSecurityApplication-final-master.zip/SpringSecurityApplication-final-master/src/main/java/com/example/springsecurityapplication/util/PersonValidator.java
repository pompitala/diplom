package com.example.springsecurityapplication.util;

import com.example.springsecurityapplication.models.Person;
import com.example.springsecurityapplication.services.PersonService;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class PersonValidator implements Validator {
    // внедряем поле через конструктор
    private final PersonService personService;

    public PersonValidator(PersonService personService) {
        this.personService = personService;
    }


    //реализовываем методы имплентированного интерфейса

    //указывает для какой модели предназначен данный валидатор
    //обращаемся к классу Person и с помощью метода equals сравним два объекта (сравнивает с тем что нам приходит в параметрах)
    @Override
    public boolean supports(Class<?> clazz) {
        return Person.class.equals(clazz);
    }

    // прописывается валидация
    // в параметры приходит объект валидации и объект ошибок
    //Этот объект валидации(он приходит как Object) надо даункастить до модели Person
    //если пользователь найден по логину(если метод findByLogin в personService нам не вернул null, то создаётся объект ошибки (ошибка по полю "login", код ошибки " " и сообщение "Такой логин уже существует")
    @Override
    public void validate(Object target, Errors errors) {
        Person person = (Person) target;
        if(personService.findByLogin(person) != null){
            errors.rejectValue("login", "","Такой логин уже существует");
        }
    }


}

package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.models.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

    //найти пользователя по id
    //т.к. мы формируем корзину на основе id пользователя
    //метод получает id, идет в сущность Cart, ищет какие товары привязаны к данному пользователю и вернет лист этих товаров
    List<Cart> findByPersonId (int id);

    //удаление из корзины
    //принимаем id и по нему удаляем
    //запрос в БД "удалить из таблицы product_cart где product_id равен первому принимаемому параметру в рамках данного метода
    @Modifying //указывает, что мы изменяем сущность в рамках БД
    @Query(value = "delete from product_cart where product_id=?1", nativeQuery = true)
    void deleteByCartProductId(int id);
}

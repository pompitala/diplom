package com.example.springsecurityapplication.configs;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.springsecurityapplication.util")//включаем сканирование компонентов
public class SpringConfig {
}

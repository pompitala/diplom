package com.example.springsecurityapplication.models;

import jakarta.persistence.*;

@Entity
@Table(name = "product_cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;

    //здесь id пользователя к которому относится данная корзина. Как только пользователь заходит в свой личный кабинет, мы можем подгружать товары(которые он ранее оставлял в корзине) и класть их в корзину
    @Column(name="person_id")
    private int personId;

    //поле отвечает за привязку к продукту (будет многие ко многим)
    @Column(name = "product_id")
    private  int productId;

    public Cart(int personId, int productId) {
        this.personId = personId;
        this.productId = productId;
    }

    public Cart() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}
